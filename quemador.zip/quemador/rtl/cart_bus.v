// Genera un ciclo de bus de Game Boy (lectura o escritura) en el conector
// del cartucho. Los tiempos se dan en ciclos de reloj; a 40 MHz, 1 ciclo = 25 ns.
//
// Escritura: DIR hacia el cartucho -> espera -> manejar D -> /WR=0 -> /WR=1 -> soltar D -> DIR de vuelta
// Lectura:   /RD=0 -> espera -> muestrear D -> /RD=1
//
// En reposo el bus de datos queda en alta impedancia y el level shifter
// apunta del cartucho hacia la FPGA, para no pelear con la ROM.

module cart_bus #(
    parameter DIR_WRITE = 1'b1,   // nivel de DIR que lleva el dato FPGA -> cartucho (ver README)
    parameter T_SETUP   = 8,      // 200 ns: direccion/dato estables antes del pulso
    parameter T_PULSE   = 20,     // 500 ns: ancho de /WR o /RD
    parameter T_HOLD    = 8       // 200 ns: dato sostenido despues de /WR
) (
    input  wire        clk,
    input  wire        rst,

    // Interfaz interna
    input  wire        start,     // pulso: iniciar un ciclo
    input  wire        is_write,
    input  wire [15:0] addr,
    input  wire [7:0]  wdata,
    output reg  [7:0]  rdata,
    output wire        busy,

    // Pines hacia el conector
    output reg  [15:0] cart_a,
    inout  wire [7:0]  cart_d,
    output reg         cart_wr_n,
    output reg         cart_rd_n,
    output wire        cart_cs_n,
    output reg         data_dir
);
    localparam IDLE = 3'd0, W_SETUP = 3'd1, W_PULSE = 3'd2, W_HOLD = 3'd3,
               R_SETUP = 3'd4, R_PULSE = 3'd5, DONE = 3'd6;

    reg [2:0]  state;
    reg [7:0]  cnt;
    reg [7:0]  wdata_r;
    reg        drive_d;

    assign cart_d    = drive_d ? wdata_r : 8'bz;
    assign cart_cs_n = 1'b1;              // /CS solo selecciona la RAM del cartucho
    assign busy      = (state != IDLE) || start;

    always @(posedge clk) begin
        if (rst) begin
            state     <= IDLE;
            cart_a    <= 16'hFFFF;
            cart_wr_n <= 1'b1;
            cart_rd_n <= 1'b1;
            drive_d   <= 1'b0;
            data_dir  <= ~DIR_WRITE;
            rdata     <= 8'h00;
        end else begin
            case (state)
                IDLE: if (start) begin
                    cart_a <= addr;
                    cnt    <= T_SETUP;
                    if (is_write) begin
                        wdata_r  <= wdata;
                        data_dir <= DIR_WRITE;
                        state    <= W_SETUP;
                    end else
                        state <= R_SETUP;
                end

                W_SETUP: begin
                    drive_d <= 1'b1;
                    if (cnt == 0) begin
                        cart_wr_n <= 1'b0;
                        cnt       <= T_PULSE;
                        state     <= W_PULSE;
                    end else
                        cnt <= cnt - 1;
                end

                W_PULSE: if (cnt == 0) begin
                    cart_wr_n <= 1'b1;
                    cnt       <= T_HOLD;
                    state     <= W_HOLD;
                end else
                    cnt <= cnt - 1;

                W_HOLD: if (cnt == 0) begin
                    drive_d  <= 1'b0;
                    data_dir <= ~DIR_WRITE;
                    cnt      <= T_HOLD;
                    state    <= DONE;
                end else
                    cnt <= cnt - 1;

                R_SETUP: if (cnt == 0) begin
                    cart_rd_n <= 1'b0;
                    cnt       <= T_PULSE;
                    state     <= R_PULSE;
                end else
                    cnt <= cnt - 1;

                R_PULSE: if (cnt == 0) begin
                    rdata     <= cart_d;
                    cart_rd_n <= 1'b1;
                    cnt       <= T_HOLD;
                    state     <= DONE;
                end else
                    cnt <= cnt - 1;

                DONE: if (cnt == 0)       // tiempo de recuperacion entre ciclos
                    state <= IDLE;
                else
                    cnt <= cnt - 1;

                default: state <= IDLE;
            endcase
        end
    end
endmodule
