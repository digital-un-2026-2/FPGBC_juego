// Puente PC <-> cartucho por UART para la FPGA de la consola FPGBC.
//
// Comandos (todos los numeros en big-endian):
//   'V'                      -> responde "FPGBC1"          (prueba de enlace)
//   'R' aH aL nH nL          -> responde n bytes leidos desde la direccion a
//                               (n = 0 significa 65536)
//   'W' aH aL d              -> un ciclo de escritura en a, responde 'K'
//   'P' aH aL d              -> programa un byte de la flash: AAA<-AA, 555<-55,
//                               AAA<-A0, a<-d, y espera con sondeo de DQ7.
//                               Responde 'K' si termino bien, 'X' si fallo.
//
// El banco del MBC5 lo elige el PC con comandos 'W' (0x2000 y 0x3000).
// Los comandos 'P' se pueden enviar en rafaga: la FIFO de recepcion los guarda.

module cart_bridge #(
    parameter CLK_HZ    = 40_000_000,
    parameter BAUD      = 115_200,
    parameter DIR_WRITE = 1'b1
) (
    input  wire        clk,
    input  wire        rst_n,       // reset de la FPGA (activo en bajo)

    input  wire        uart_rx,
    output wire        uart_tx,

    output wire [15:0] cart_a,
    inout  wire [7:0]  cart_d,
    output wire        cart_wr_n,
    output wire        cart_rd_n,
    output wire        cart_cs_n,
    output wire        cart_clk,
    output wire        cart_rst_n,  // /RESET del cartucho (el EverSave no lo usa)
    output wire        data_dir,    // DIR del level shifter de datos (SN74LVC8T245)
    output wire        ctrl_oe      // OE del level shifter de control (TXB0104, activo en alto)
);
    localparam CLKS_PER_BIT = CLK_HZ / BAUD;
    localparam POLL_LIMIT   = 24'd200_000;  // lecturas de sondeo antes de rendirse

    wire rst = ~rst_n;

    assign cart_clk   = 1'b0;
    assign cart_rst_n = 1'b1;
    assign ctrl_oe    = 1'b1;

    // ---------------- UART + FIFO de recepcion ----------------
    wire [7:0] rx_byte;
    wire       rx_valid;
    uart_rx #(.CLKS_PER_BIT(CLKS_PER_BIT)) u_rx (
        .clk(clk), .rst(rst), .rx(uart_rx), .data(rx_byte), .valid(rx_valid)
    );

    reg  [7:0] fifo [0:511];
    reg  [8:0] wr_ptr, rd_ptr;
    wire       fifo_empty = (wr_ptr == rd_ptr);
    reg  [7:0] fifo_out;
    reg        fifo_pop;

    always @(posedge clk) begin
        if (rx_valid)
            fifo[wr_ptr] <= rx_byte;
        fifo_out <= fifo[rd_ptr];
    end
    always @(posedge clk) begin
        if (rst) begin
            wr_ptr <= 0;
            rd_ptr <= 0;
        end else begin
            if (rx_valid) wr_ptr <= wr_ptr + 1;
            if (fifo_pop) rd_ptr <= rd_ptr + 1;
        end
    end

    reg  [7:0] tx_byte;
    reg        tx_start;
    wire       tx_busy;
    uart_tx #(.CLKS_PER_BIT(CLKS_PER_BIT)) u_tx (
        .clk(clk), .rst(rst), .data(tx_byte), .start(tx_start), .tx(uart_tx), .busy(tx_busy)
    );

    // ---------------- Ciclos de bus ----------------
    reg         bus_start, bus_write;
    reg  [15:0] bus_addr;
    reg  [7:0]  bus_wdata;
    wire [7:0]  bus_rdata;
    wire        bus_busy;

    cart_bus #(.DIR_WRITE(DIR_WRITE)) u_bus (
        .clk(clk), .rst(rst),
        .start(bus_start), .is_write(bus_write), .addr(bus_addr), .wdata(bus_wdata),
        .rdata(bus_rdata), .busy(bus_busy),
        .cart_a(cart_a), .cart_d(cart_d), .cart_wr_n(cart_wr_n), .cart_rd_n(cart_rd_n),
        .cart_cs_n(cart_cs_n), .data_dir(data_dir)
    );

    // ---------------- Interprete de comandos ----------------
    localparam S_IDLE    = 5'd0,  S_POP     = 5'd1,  S_ARGS    = 5'd2,
               S_DISPATCH= 5'd3,  S_VER     = 5'd4,  S_RD_BUS  = 5'd5,
               S_RD_WAIT = 5'd6,  S_RD_TX   = 5'd7,  S_WR_BUS  = 5'd8,
               S_WR_WAIT = 5'd9,  S_ACK     = 5'd10, S_PG_STEP = 5'd11,
               S_PG_WAIT = 5'd12, S_POLL    = 5'd13, S_POLL_W  = 5'd14,
               S_TX_WAIT = 5'd15, S_ARG_POP = 5'd16;

    reg [4:0]  state, after_tx;
    reg [7:0]  cmd;
    reg [7:0]  args [0:3];
    reg [2:0]  nargs, argi;
    reg [16:0] remaining;
    reg [2:0]  step;
    reg [2:0]  ver_i;
    reg [23:0] polls;
    reg        dq5_seen;
    reg [7:0]  ack;

    wire [15:0] a_arg = {args[0], args[1]};

    function [7:0] ver_char(input [2:0] i);
        case (i)
            3'd0: ver_char = "F";
            3'd1: ver_char = "P";
            3'd2: ver_char = "G";
            3'd3: ver_char = "B";
            3'd4: ver_char = "C";
            default: ver_char = "1";
        endcase
    endfunction

    always @(posedge clk) begin
        if (rst) begin
            state     <= S_IDLE;
            fifo_pop  <= 1'b0;
            tx_start  <= 1'b0;
            bus_start <= 1'b0;
        end else begin
            fifo_pop  <= 1'b0;
            tx_start  <= 1'b0;
            bus_start <= 1'b0;

            case (state)
                // Esperar un byte de comando
                S_IDLE: if (!fifo_empty) begin
                    fifo_pop <= 1'b1;
                    state    <= S_POP;
                end

                S_POP: begin                     // fifo_out ya tiene el byte
                    cmd  <= fifo_out;
                    argi <= 0;
                    case (fifo_out)
                        "R":     begin nargs <= 4; state <= S_ARGS; end
                        "W","P": begin nargs <= 3; state <= S_ARGS; end
                        "V":     begin ver_i <= 0; state <= S_VER;  end
                        default: state <= S_IDLE;    // byte desconocido: se ignora
                    endcase
                end

                // Leer los argumentos de la FIFO
                S_ARGS: if (argi == nargs)
                    state <= S_DISPATCH;
                else if (!fifo_empty) begin
                    fifo_pop <= 1'b1;
                    state    <= S_ARG_POP;
                end

                S_ARG_POP: begin
                    args[argi] <= fifo_out;
                    argi       <= argi + 1;
                    state      <= S_ARGS;
                end

                S_DISPATCH: case (cmd)
                    "R": begin
                        bus_addr  <= a_arg;
                        remaining <= ({args[2], args[3]} == 16'd0) ? 17'h10000 : {1'b0, args[2], args[3]};
                        state     <= S_RD_BUS;
                    end
                    "W": begin
                        bus_addr  <= a_arg;
                        bus_wdata <= args[2];
                        state     <= S_WR_BUS;
                    end
                    default: begin               // 'P'
                        step  <= 0;
                        state <= S_PG_STEP;
                    end
                endcase

                // 'V': enviar "FPGBC1"
                S_VER: if (!tx_busy) begin
                    tx_byte  <= ver_char(ver_i);
                    tx_start <= 1'b1;
                    after_tx <= (ver_i == 5) ? S_IDLE : S_VER;
                    ver_i    <= ver_i + 1;
                    state    <= S_TX_WAIT;
                end

                // 'R': leer y enviar byte por byte
                S_RD_BUS: if (!bus_busy) begin
                    bus_write <= 1'b0;
                    bus_start <= 1'b1;
                    state     <= S_RD_WAIT;
                end
                S_RD_WAIT: if (!bus_busy && !bus_start)
                    state <= S_RD_TX;
                S_RD_TX: if (!tx_busy) begin
                    tx_byte   <= bus_rdata;
                    tx_start  <= 1'b1;
                    bus_addr  <= bus_addr + 1;
                    remaining <= remaining - 1;
                    after_tx  <= (remaining == 1) ? S_IDLE : S_RD_BUS;
                    state     <= S_TX_WAIT;
                end

                // 'W': una escritura
                S_WR_BUS: begin
                    bus_write <= 1'b1;
                    bus_start <= 1'b1;
                    state     <= S_WR_WAIT;
                end
                S_WR_WAIT: if (!bus_busy && !bus_start) begin
                    ack   <= "K";
                    state <= S_ACK;
                end

                // 'P': secuencia de programacion de la flash (modo byte)
                S_PG_STEP: begin
                    bus_write <= 1'b1;
                    case (step)
                        3'd0: begin bus_addr <= 16'h0AAA; bus_wdata <= 8'hAA; end
                        3'd1: begin bus_addr <= 16'h0555; bus_wdata <= 8'h55; end
                        3'd2: begin bus_addr <= 16'h0AAA; bus_wdata <= 8'hA0; end
                        default: begin bus_addr <= a_arg; bus_wdata <= args[2]; end
                    endcase
                    bus_start <= 1'b1;
                    state     <= S_PG_WAIT;
                end
                S_PG_WAIT: if (!bus_busy && !bus_start) begin
                    if (step == 3) begin
                        polls    <= 0;
                        dq5_seen <= 1'b0;
                        state    <= S_POLL;
                    end else begin
                        step  <= step + 1;
                        state <= S_PG_STEP;
                    end
                end

                // Sondeo de DQ7 (y DQ5 como senal de error)
                S_POLL: begin
                    bus_addr  <= a_arg;
                    bus_write <= 1'b0;
                    bus_start <= 1'b1;
                    polls     <= polls + 1;
                    state     <= S_POLL_W;
                end
                S_POLL_W: if (!bus_busy && !bus_start) begin
                    if (bus_rdata[7] == args[2][7]) begin
                        ack   <= "K";
                        state <= S_ACK;
                    end else if (dq5_seen || polls == POLL_LIMIT) begin
                        ack   <= "X";
                        state <= S_ACK;      // el PC debe enviar reset (F0)
                    end else begin
                        dq5_seen <= bus_rdata[5];  // releer una vez mas tras DQ5=1
                        state    <= S_POLL;
                    end
                end

                S_ACK: if (!tx_busy) begin
                    tx_byte  <= ack;
                    tx_start <= 1'b1;
                    after_tx <= S_IDLE;
                    state    <= S_TX_WAIT;
                end

                S_TX_WAIT: if (!tx_start && tx_busy)   // esperar a que el byte arranque
                    state <= after_tx;

                default: state <= S_IDLE;
            endcase
        end
    end
endmodule
