// UART 8N1 sencilla (receptor y transmisor) para el puente del cartucho.
// CLKS_PER_BIT = frecuencia del reloj / baudios.

module uart_rx #(
    parameter CLKS_PER_BIT = 347          // 40 MHz / 115200
) (
    input  wire       clk,
    input  wire       rst,
    input  wire       rx,
    output reg  [7:0] data,
    output reg        valid               // pulso de un ciclo con un byte nuevo
);
    localparam IDLE = 2'd0, START = 2'd1, BITS = 2'd2, STOP = 2'd3;

    reg [1:0]  state;
    reg [15:0] cnt;
    reg [2:0]  bit_idx;
    reg        rx_s1, rx_s2;              // sincronizador de la entrada

    always @(posedge clk) begin
        rx_s1 <= rx;
        rx_s2 <= rx_s1;
    end

    always @(posedge clk) begin
        if (rst) begin
            state <= IDLE;
            valid <= 1'b0;
            cnt   <= 0;
        end else begin
            valid <= 1'b0;
            case (state)
                IDLE: if (!rx_s2) begin
                    cnt   <= CLKS_PER_BIT / 2;
                    state <= START;
                end
                START: if (cnt == 0) begin
                    if (!rx_s2) begin     // bit de inicio valido a mitad de bit
                        cnt     <= CLKS_PER_BIT - 1;
                        bit_idx <= 0;
                        state   <= BITS;
                    end else
                        state <= IDLE;
                end else
                    cnt <= cnt - 1;
                BITS: if (cnt == 0) begin
                    data[bit_idx] <= rx_s2;
                    cnt <= CLKS_PER_BIT - 1;
                    if (bit_idx == 7)
                        state <= STOP;
                    bit_idx <= bit_idx + 1;
                end else
                    cnt <= cnt - 1;
                STOP: if (cnt == 0) begin
                    valid <= rx_s2;       // se descarta si no hay bit de parada
                    state <= IDLE;
                end else
                    cnt <= cnt - 1;
            endcase
        end
    end
endmodule

module uart_tx #(
    parameter CLKS_PER_BIT = 347
) (
    input  wire       clk,
    input  wire       rst,
    input  wire [7:0] data,
    input  wire       start,              // pulso: enviar data
    output reg        tx,
    output wire       busy
);
    reg [9:0]  shift;
    reg [3:0]  bits_left;
    reg [15:0] cnt;

    assign busy = (bits_left != 0) || (cnt != 0);

    always @(posedge clk) begin
        if (rst) begin
            tx        <= 1'b1;
            bits_left <= 0;
            cnt       <= 0;
        end else if (bits_left == 0) begin
            tx <= 1'b1;
            if (cnt != 0)                 // terminando el bit de parada
                cnt <= cnt - 1;
            else if (start) begin
                shift     <= {1'b1, data, 1'b0};   // parada, datos, inicio
                bits_left <= 10;
                cnt       <= 0;
            end
        end else if (cnt == 0) begin
            tx        <= shift[0];
            shift     <= {1'b1, shift[9:1]};
            bits_left <= bits_left - 1;
            cnt       <= CLKS_PER_BIT - 1;
        end else
            cnt <= cnt - 1;
    end
endmodule
